/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "encoder.h"
#include "stdio.h"
#include "IIC.h"
#include "mpu6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"

    int num1=0,num2=0,m,n;
    int iTimerEncoder_A;
    int iTimerEncoder_B;
    int countnum_A;
    int countnum_B;
    double REALSPEED_A;
    double REALSPEED_B;
    int a=0;   
    int MOTOR_speed1,MOTOR_speed2;
    char TX_targetspeed_A;
    char TX_targetspeed_B;
    ////////////////

    float pitch,roll,yaw; 		    //ŷ����
    short aacx,aacy,aacz;			//���ٶȴ�����ԭʼ����
    short gyrox,gyroy,gyroz;		//������ԭʼ����
    float temp;					    //�¶�
    
    /////////////////
    int temp_pitch;
    int temp_roll;
    int temp_yaw;
    float pitch1;
    float roll1;
    float yaw1;

    /////////////////
/*ʵ���ٶ�����     �����ٶ�*/
volatile float  pulse_speed_A=0,pulse_target_A=0;
volatile float  pulse_speed_B=0,pulse_target_B=0;
/*pwm�ͱ�������ȡֵ*/

volatile int USINGPWM_A=0;
volatile int Error_Last_A,Error_Prev_A;//��һ��ƫ����ϴ�ƫ��
volatile float pwm_A=0,PIDpulse_add_A;//pwm������pwm��ռ�ձ�

float Kp_A =3, Ki_A =2, Kd_A = 0.1;//PID����

volatile int USINGPWM_B=0;
volatile int Error_Last_B,Error_Prev_B;//��һ��ƫ����ϴ�ƫ��
volatile float pwm_B=0,PIDpulse_add_B;//pwm������pwm��ռ�ձ�

float Kp_B =3,Ki_B =2, Kd_B = 0.1;//PID����
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

///////////////////////////////////////////////////////////////////
//pid��ʽ��PIDpulse_add += Kp * (Error - Error_Last) + Ki * Error +	Kd * (Error - 2.0 * Error_Last + Error_Prev);
/*pid���㺯��������ֵΪPWM*/
float SpeedInnerControl_A(float pulse_speed,float pulse_target)
{		
		
	
    float Error =pulse_target  - pulse_speed;	//�趨����ֵ - ʵ������

    PIDpulse_add_A = Kp_A * (Error - Error_Last_A) + 									
							Ki_A * Error +																		
							Kd_A * (Error - 2.0 * Error_Last_A + Error_Prev_A);	//���λ�ü�ȥ2.0��ͨʽ����ʽpid����Ҫ��ȥ���2.0


   USINGPWM_A += PIDpulse_add_A;		//����PID
	
		Error_Prev_A = Error_Last_A;//	Error_Prev���ϴ����
    Error_Last_A = Error;	//Error_Last�ϴ����
		
		if(USINGPWM_A <  0  ) USINGPWM_A = -USINGPWM_A;
		if(USINGPWM_A > 1000 ) USINGPWM_A  = 1000;

    return USINGPWM_A;	
}

float SpeedInnerControl_B(float pulse_speed,float pulse_target)
{		
		
	
    float Error =pulse_target  - pulse_speed;	//�趨����ֵ - ʵ������

    PIDpulse_add_B = Kp_B * (Error - Error_Last_B) + 									
							Ki_B * Error +																		
							Kd_B * (Error - 2.0 * Error_Last_B + Error_Prev_B);	//���λ�ü�ȥ2.0��ͨʽ����ʽpid����Ҫ��ȥ���2.0


   USINGPWM_B += PIDpulse_add_B;		//����PID
	
		Error_Prev_B = Error_Last_B;//	Error_Prev���ϴ����
    Error_Last_B = Error;	//Error_Last�ϴ����
		
		if(USINGPWM_B <  0  ) USINGPWM_B = -USINGPWM_B;
		if(USINGPWM_B > 1000 ) USINGPWM_B  = 1000;

    return USINGPWM_B;	
}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
 void delay(int a)
 {
     for(int i=0;i<a;i++)
       for(int j=0;j<2000;j++);
 }
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM8_Init();
  MX_TIM2_Init();
  MX_TIM1_Init();
  MX_TIM5_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);//PWM
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);
    
    HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);//encoder modle
    HAL_TIM_Encoder_Start(&htim8, TIM_CHANNEL_ALL);
    
    HAL_TIM_Base_Start_IT(&htim1);
    HAL_TIM_Base_Start_IT(&htim2); 
    HAL_TIM_Base_Start_IT(&htim5);     
    
        MPU_Init();			//MPU6050��ʼ��
    mpu_dmp_init();		//dmp��ʼ��
    
    HAL_GPIO_WritePin(CS_Addr_GPIO_Port,CS_Addr_Pin,GPIO_PIN_RESET);
    
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
//        HAL_UART_Transmit(&huart2,&put,1,50);


  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    //////////////////��ȡ�������������/////////////////////
        while(mpu_dmp_get_data(&pitch, &roll, &yaw));	//����Ҫ��while�ȴ������ܶ�ȡ�ɹ�
        MPU_Get_Accelerometer(&aacx,&aacy, &aacz);		//�õ����ٶȴ���������
        MPU_Get_Gyroscope(&gyrox, &gyroy, &gyroz);		//�õ�����������
        temp=MPU_Get_Temperature();						//�õ��¶���Ϣ
    //////////////////////////////////////////////////////////    
  
    ////////״̬��ʾ����
      
      //HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_RESET);
      //HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,GPIO_PIN_RESET);
      //HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_SET);
      //HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,GPIO_PIN_SET);
      
    ////�������ݴ���
      
      //TX_targetspeed_A = (char) countnum_A;
      //TX_targetspeed_B = (int) pulse_target_B; 
      // HAL_UART_Transmit(&huart2,mpu_data1,1,50); 
      
   ////////////���ݻ���////////////////
      pitch1 = pitch*8;
      yaw1 = yaw*8;
      roll1 = roll*8;
      
      temp_pitch = (int)pitch1;
      
      
   ////////////������ƴ���PID//////////////////////   
      pulse_target_A=55-temp_pitch;//�����ٶ�Ŀ��ֵ
      pulse_target_B=55+temp_pitch;//�����ٶ�Ŀ��ֵ
      
      MOTOR_speed1 = USINGPWM_A;//����PWMֵ
      MOTOR_speed2 = USINGPWM_B;
      
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,MOTOR_speed1);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,MOTOR_speed2);
      
    ////////////////////////////////////////////////  
      

   
      
    
    


      
    
    

    
    

    

      

//      
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

      if(htim == &htim1)
   {		
			
	//	n=(float)encoder_counter*60/15.6;//ת�ټ��㣨ÿ���ӣ�

			
		pulse_speed_A = countnum_A;//��ǰ�ٶ� = ��������ȡ��������
				
		SpeedInnerControl_A(pulse_speed_A,pulse_target_A);//����ǰ��ȡ����������������бȽϣ�����pid����
       
       	pulse_speed_B = countnum_B;//��ǰ�ٶ� = ��������ȡ��������
				
		SpeedInnerControl_B(pulse_speed_B,pulse_target_B);//����ǰ��ȡ����������������бȽϣ�����pid����
   }  
    
  if(htim == &htim2)
  {
      
    a++; //�ٶȲ�����ʱ��
       
    m = iTimerEncoder_A ;
    n = iTimerEncoder_B ;
  //      m = GetTimEncoder_A();
  //      n = GetTimEncoder_B();
      
   countnum_A =  m - num1;
   countnum_B =  n - num2;
      
   REALSPEED_A=  COUNTSPEED (countnum_A);
   REALSPEED_B=  COUNTSPEED (countnum_B);
      
      num1 = m;
      num2 = n;
      HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_RESET);
      HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,GPIO_PIN_RESET);
    iTimerEncoder_A = 0;
    iTimerEncoder_B = 0;
   //     __HAL_TIM_SET_COUNTER(&htim4,0);
   //     __HAL_TIM_SET_COUNTER(&htim8,0);
  }
  
   if(htim == &htim3)
   {
   }
   if(htim == &htim4)
   {
   }
   if(htim == &htim5)
   {
        iTimerEncoder_A = GetTimEncoder_A();
        iTimerEncoder_B = GetTimEncoder_B();
   }
      if(htim == &htim8)
   {
   }
  
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
