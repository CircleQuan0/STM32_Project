//#include "main.h"
//#include "PID.h"


//int Timer = 0;			//ʱ��
//int speed = 0;		//��ǰPWM
//short TargetSpeed = 10; //Ŀ���ٶ�

//extern int MOTOR_speed1;
//extern int MOTOR_speed2;

///*PID����*/
//#define kp 0.86
//#define ki 0.012
//#define kd 0.005


////�ٶȸ�ֵ
//void GetSpeed(int a,int b)
//{
//	MOTOR_speed1 =a;
//    MOTOR_speed2 =b;
//	
//}


////
//short PID_Cal(short Speed,short *error)
//{
//	short Error = TargetSpeed - Speed;
//	static short Error_last = 0,Error_prev = 0;
//	short pwm_add=0;
//	*error = Error;
//	pwm_add = kp*(Error - Error_last) + ki*Error + kd*(Error-2.0f*Error_last+Error_prev);
//	
//	Error_prev = Error_last;	  	    // �������ϴ����
//  Error_last = Error;	              // �����ϴ�ƫ��
//	
//	
//	return pwm_add;
//}

