//#ifndef __PID_H
//#define	__PID_H

//#include "stm32f1xx.h"
//#include "main.h"

//void GetSpeed(int a,int b);
//short PID_Cal(short Speed,short *error);

//#endif
