#ifndef __ENCODER_H
#define	__ENCODER_H

#include "stm32f1xx.h"
#include "tim.h"


int GetTimEncoder_A(void);
int GetTimEncoder_B(void);
int COUNTSPEED (int encoder_num);

#endif