#ifndef __ENCODER_H
#define	__ENCODER_H

#include "stm32f1xx.h"
#include "tim.h"

int GetTimEncoder(void);

#endif