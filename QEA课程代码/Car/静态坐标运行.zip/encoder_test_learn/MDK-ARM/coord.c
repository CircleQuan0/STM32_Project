#include "coord.h"
#include "PID.h"
#include "math.h"
#include "tim.h"

extern int pulse_target_A,pulse_target_B;
extern int MOTOR_speed1,MOTOR_speed2;
extern int USINGPWM_A,USINGPWM_B;

extern int iTimerEncoder_A;//T4go
extern int iTimerEncoder_B;
    int rel_distance1 = 0;
    int test_dis = 0;
    int derrr_yaw = 0;

int der_yaw=0;
int derr_yaw=0;

pid_struct_t yawpid;
fp32 yaw_pid[3]={40,0,2};

extern float yaw;//ʵ��yawֵ

float X0,Y0,X,Y;//��ʼ������Ŀ������

float distance_a;
float angle_a;

void coord_init()//��ʼ������
{
    X =0;
    Y =0;
}

float coord_distance(float x0,float y0,float x,float y)//������㺯��
{
    float distant;
    distant=sqrt((pow(x-x0,2))+(pow(y-y0,2)));   
    return distant;
}
float coord_angle(float x0,float y0,float x,float y)//�Ƕȼ��㺯��
{
    float angle;
    float sin1;
    float distant0;
    distant0=sqrt((pow(x-x0,2))+(pow(y-y0,2)));   
    sin1=(x-x0)/distant0;
    angle=asin(sin1) * 180 /3.1415;   
    return angle;   
}

void coord_yaw(float target_yaw)//�Ƕ�ִ�к���
{
    
    derrr_yaw=target_yaw-yaw;
    der_yaw = (int)(pid_calc(&yawpid,yaw,target_yaw));
    
           if(derrr_yaw>=0)
       {
           int Z_motor=abs(der_yaw);
           
        if(Z_motor>10)
        {
              __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,0);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,Z_motor);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,Z_motor);
        }    
        else if(Z_motor<=10)
        {
              __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,0);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,Z_motor);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,Z_motor);
        }}

       else //��ת
       {
           int Y_motor=abs(der_yaw);
        if(Y_motor>10)
        {
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,Y_motor);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,Y_motor);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,0);
        }
        else if(Y_motor<=10)
        {
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,Y_motor);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,Y_motor);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,0);  
        }

       }     
}


void coord_stright_go(int dis)//ֱ�ߺ���
    
{
    

    __HAL_TIM_SET_COUNTER(&htim4,0);
   // iTimerEncoder_A=0;
    osDelay(10);
    rel_distance1 = iTimerEncoder_A/100;
    osDelay(10);
    while(dis-rel_distance1>=3 || dis-rel_distance1<=-3)
        {

rel_distance1 = iTimerEncoder_A/100;

     // osDelay(1);
            osDelay(1);
    if(dis-rel_distance1>3)
    {
        rel_distance1 = iTimerEncoder_A/100;
            test_dis = dis-rel_distance1;
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,450);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,450);  
        osDelay(1);

    }
    else if(dis-rel_distance1<=3 && dis-rel_distance1>=0)
    {
        rel_distance1 = iTimerEncoder_A/100;
    test_dis = dis-rel_distance1;
        
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,(dis-rel_distance1)*26  );//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,(dis-rel_distance1)*26  );//
osDelay(1);        
    }
    else
    {
         rel_distance1 = iTimerEncoder_A/100;
            test_dis = dis-rel_distance1;
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,0);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,(dis-rel_distance1)*26);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,(dis-rel_distance1)*26);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,0);  
        osDelay(1);
    } 
}
    
}
void pwm_init()
{
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,0);//PWMͨ����ֵ
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,0);
      __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,0); 
}


void coord_go(float x0,float y0,float x,float y)//ִ�к���
{
      pwm_init();
     distance_a = (int)(coord_distance(x0,y0,x,y));
     angle_a =coord_angle(x0,y0,x,y);
    
    derrr_yaw = (int)(angle_a-yaw);

  while(derrr_yaw<-2||derrr_yaw>2)
  {
      coord_yaw(angle_a);
      
  }
      
   coord_stright_go(distance_a);
  pwm_init();
  osDelay(1);
      
}










