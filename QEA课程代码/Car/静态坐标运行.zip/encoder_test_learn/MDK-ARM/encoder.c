#include "encoder.h"


extern int iTimerEncoder_A;
extern int iTimerEncoder_B;

int GetTimEncoder_A(void)
{
    
  iTimerEncoder_A=(short)(__HAL_TIM_GET_COUNTER(&htim4));
 // __HAL_TIM_SET_COUNTER(&htim4,0);
    
  return   iTimerEncoder_A;
}


int GetTimEncoder_B(void)
{
    int num=(short)(__HAL_TIM_GET_COUNTER(&htim8));
     iTimerEncoder_B = -num;
//  __HAL_TIM_SET_COUNTER(&htim8,0);
    
  return   iTimerEncoder_B;
}

int COUNTSPEED (int encoder_num)
{
    double distance;
     distance =(60.288*encoder_num)/2340;

    return  distance;
}

