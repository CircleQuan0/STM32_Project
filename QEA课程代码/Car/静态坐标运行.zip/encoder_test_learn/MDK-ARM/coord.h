#ifndef __Coord_H
#define	__Coord_H

#include "stm32f1xx.h"


void coord_init();
float coord_distance(float x0,float y0,float x,float y);
float coord_angle(float x0,float y0,float x,float y);
void coord_yaw(float target_yaw);
void coord_stright_go(int dis);
void coord_go(float x0,float y0,float x,float y);
void pwm_init();




#endif