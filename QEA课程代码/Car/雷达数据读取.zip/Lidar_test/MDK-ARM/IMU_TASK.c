    #include "IIC.h"      //����ģ��I2C
#include "mpu6050.h"  //mpu6050�Ĵ����������
#include "inv_mpu.h"  //dmp���
#include "inv_mpu_dmp_motion_driver.h"  //dmp���
#include "IMU_TASK.h"
#include "Lidar.h"
#include "tim.h"
#include "math.h"
#include "stdio.h"
#include "pid.h"
extern int flag;
extern car_struct car;
int GetDataL;//��������ֵ
int GetDataR;//��������ֵ
//int v1 = w+x;
//int v2 = x-w;
int juli;
		pid_struct_t carpid;
		fp32 car_pid[3]={20,0,0};
		float pitch,roll,yaw; 		    //ŷ����
    short aacx,aacy,aacz;			//���ٶȴ�����ԭʼ����
    short gyrox,gyroy,gyroz;		//������ԭʼ����
    float temp;					    //�¶�
		int x[100];
		int y[100];
void turnleft(int y)
{
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_1,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_2,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_3,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_4,0);


}
void turnright(int y)
{
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_1,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_2,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_3,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_4,0);


}
void turngo(int y)
{
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_1,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_2,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_3,0);
	__HAL_TIM_SET_COMPARE (&htim3,TIM_CHANNEL_4,0);


}
double calculateAngle(int x1, int y1, int x2, int y2) {
    double deltaX = x2 - x1;
    double deltaY = y2 - y1;
    double angle = atan2(deltaY, deltaX) * 180 / 3.1415;
    return angle;
}

void imutask(void const * argument){
	for(;;)
	{
		 while(mpu_dmp_get_data(&pitch, &roll, &yaw));	//����Ҫ��while�ȴ������ܶ�ȡ�ɹ�
        MPU_Get_Accelerometer(&aacx,&aacy, &aacz);		//�õ����ٶȴ���������
       MPU_Get_Gyroscope(&gyrox, &gyroy, &gyroz);		//�õ�����������
       temp=MPU_Get_Temperature();						//�õ��¶���Ϣ}
			car.yaw = yaw;
		osDelay(1);
	}}
int car_init()
	{
	car.x=0;
		car.y=0;
		car.yaw = yaw;
	}
void move(int x,int y)
{
	pid_init(&carpid, car_pid, 4000, 4000);
	car.len = sqrt((x-car.x)*(x-car.x)+(y-car.y)*(y-car.y));
	car.targeyaw = calculateAngle(car.x,car.y,x,y);
	while(car.targeyaw-car.yaw>-1||car.targeyaw-car.yaw<-1)
	{
		
		if(car.targeyaw-car.yaw>-1)
		{
			
			turnleft(car.targeyaw);
		}
		if(car.targeyaw-car.yaw<-1)
		{
			turnright(car.targeyaw);
		}
	}
	while(GetDataL<car.len)
	{
		int targespeed = pid_calc(&carpid,GetDataL,car.len);
		turngo(targespeed);
		
			
}
car.x = x;
car.y = y;
car.yaw = yaw;
}
void cartask(void const * argument){
	for(;;)
	{
		 for(int i = 0;i<100;i++)
		{
			move(x[i],y[i]);
		}

		osDelay(1);
	}}

void counter()
{

GetDataL = __HAL_TIM_GET_COUNTER(&htim4);//0λ����1Ϊ��
	GetDataR = __HAL_TIM_GET_COUNTER(&htim8);//0λ����1Ϊ��


}